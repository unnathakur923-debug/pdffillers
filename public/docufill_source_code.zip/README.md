# DocuFill Studio & Bank Letters Portal - Source Code
Thakur Xerox Center — Contact: Vinodsingh Thakur (9970996060)

## Quick Start (Local Development)
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start development server:
   ```bash
   npm run dev
   ```
3. Build for production (Hostinger, cPanel, Apache):
   ```bash
   npm run build
   ```
4. Upload all contents of the `dist/` folder to your Hostinger `public_html/`.
