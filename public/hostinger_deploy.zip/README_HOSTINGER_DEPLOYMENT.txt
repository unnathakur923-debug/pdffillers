======================================================================
  HOSTINGER 1-MINUTE DEPLOYMENT INSTRUCTIONS
  DocuFill Studio & Bank Letters Portal - Thakur Xerox Center
======================================================================

THIS ZIP WORKS ON BOTH HOSTINGER DEPLOYMENT OPTIONS:

METHOD 1: Hostinger "Node Setup" / "Quick Install Node Setup" (Your current screen)
----------------------------------------------------------------------
1. In the Hostinger Node upload box, upload: pdf-filler-app.zip
2. Hostinger detects: Node.js / Express / Vite
3. Root directory: /
4. Start script: npm start (which executes "node server.js")
5. Port: 3000 (or default)
6. Click Deploy. Your site is live!

METHOD 2: Hostinger Standard File Manager (public_html) — Easiest!
----------------------------------------------------------------------
1. If you are on the Node screen, click "Set up manually" at the top right.
2. Go to Hostinger hPanel -> "Websites" -> "Manage" -> "File Manager".
3. Open folder: public_html
4. Upload hostinger_deploy.zip and click "Extract".
5. All files (index.html, assets, .htaccess, ads.txt) will be live instantly!

ADSENSE VERIFICATION:
The ads.txt file is included with your publisher ID:
google.com, pub-3166168589952262, DIRECT, f08c47fec0942fa0
Verify at: https://yourdomain.com/ads.txt

For support, contact Vinodsingh Thakur at 9970996060.
======================================================================
